<?php
session_start();
include("php/config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query the database to fetch the user's data
    $result = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Password is correct, create session and redirect to landing page
            $_SESSION['username'] = $user['username'];
            header("Location: landing.php");
            exit();
        } else {
            // Password is incorrect
            $error_message = "Incorrect password!";
        }
    } else {
        // User does not exist
        $error_message = "User not found!";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Log In Or Create an account.</title>
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body>
    <div class="formcontainer">
        <form method="post" action="login.php" class="container" onsubmit="return validateForm()">



            <section class="header">
                <h1 class="formheader">Log In</h1>
            </section>

            <section class="inputfields">
                <section class="username">
                    <label for="username"><b>Username</b></label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </section>

                <section class="password">
                    <label for="password"><b>Password</b></label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </section>

                <section class="checkbox1">
                    <input type="checkbox" id="rememberme" name="remember" value="rememberme">
                    <label id="checkboxlabel" for="rememberme">Remember me</label><br>
                </section>

                <section class="signbutton">
                    <button type="submit" class="signinbtn">Sign In</button>
                </section>

                <section class="create">
                    <h2 class="info">Don't have an account?</h2>
                    <button class="createacc" type="button" onclick="redirect1()">Create account</button>
                </section>
            </section>
        </form>

        <p id="error-message" style="color: white; display: none; position: absolute; width:400px; background:red; height:40px; border-radius:15px; top:-85px; padding-left:5%; padding-top:2%; box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;  ">Please fill out both username and password fields.</p>
    </div>

    <script>
        function redirect1() {
            window.location.href = "createaccount.php";
        }

        function validateForm() {
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;

            if (username.trim() === "" || password.trim() === "") {
                document.getElementById("error-message").style.display = "block";
                setTimeout(function(){
                    document.getElementById("error-message").style.display = "none";
                }, 3000); // Disappear after 3 seconds
                return false; // Prevent form submission
            } else {
                document.getElementById("error-message").style.display = "none";
                return true; // Allow form submission
            }
        }
    </script>
</body>
</html>