<?php
include("php/config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password']; // Make sure to hash the password before storing it
    $email = $_POST['email'];

    // Server-side email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format!";
        exit; // Stop further processing
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Verify unique email
    $verify_query = mysqli_query($con, "SELECT email FROM users WHERE email = '$email'");

    if (mysqli_num_rows($verify_query) != 0) {
        echo "<div class='message'><p>This email has already been used!</p></div> <br>";
        echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button></a>";
    } else {
        // Insert user into database
        $insert_query = mysqli_query($con, "INSERT INTO users (name, username, password, email) VALUES ('$name', '$username', '$hashedPassword', '$email')");

        if ($insert_query) {
            echo "<div style='background-color: #ccffcc; padding: 10px; border: 1px solid #00ff00;'><p>Registration successful!</p></div> <br>";
            echo "<a href='login.php'><button class='btn'>Login Now</button></a>";
        } else {
            // Print detailed error message
            echo "Error occurred while registering: " . mysqli_error($con);
        }
    }
} else {
    // Handle other cases (if needed)
}

// Remember me functionality
if (isset($_POST['remember'])) {
    // Assuming you have a variable containing the username, update $username with the actual username
    $username = $_POST['username']; // Replace this with the actual username variable
    $cookie_name = "remember_me";
    $cookie_value = $username;
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // Cookie valid for 30 days
}
?>