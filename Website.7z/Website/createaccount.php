<!DOCTYPE html>
<html>
<head>
    <title>Create an account</title>
    <link rel="stylesheet" href="createaccountstyle.css">
</head>
<body>
    <form class="container" action="register.php" method="post">
        <h1 class="formheader">Create an account</h1>
        <section class="name">
            <label for="name"><b>Name</b></label>
            <input type="text" id="name" name="name" placeholder="Enter your name" required>
        </section>
        <section class="username">
            <label for="username"><b>Username</b></label>
            <input type="text" id="username" name="username" placeholder="Choose a username" required>
        </section>
        <section class="password">
            <label for="password"><b>Choose a password</b></label>
            <input type="password" id="password" name="password" placeholder="Choose a password" required>
        </section>
        <section class="email">
            <label for="email"><b>Enter your email</b></label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
        </section>
        <section class="buttons">
            <button type="submit" class="signinbtn" name="submit"><span class="btntitle0">Create</span></button>
            <button onClick="myFunction()" type="button" class="discardbtn"><span class="btntitle1">Go back</span></button>
        </section>
    </form>
    <script>
        function myFunction() {
          window.location.href = "login.php";
        }
    </script>
</body>
</html>