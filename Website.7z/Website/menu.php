
<!DOCTYPE html>
<html>
    <head>
        <title>Aura | Restaurant</title>
        <link rel="stylesheet" href="menustyle.css">
    </head>
    <body>
        <section class="maintext">
             <section class="texts">
            <h1 class="herotext">Take a look at our menu.</h1>
            <h2 class="subtext">Beautifully crafted, just for yourt tastebuds.</h2>
        </section>
    
        </section>

        <section class="logo">
        <img src="http://localhost/website/Logo.png">
        </section>

        <?php
    session_start();
    ?>

  
<ul class="navigation">
        <?php
        // Check if user is logged in
        if(isset($_SESSION['username'])):
        ?>
        <li><a href="#about"><?php echo $_SESSION['username']; ?></a></li>
        <li><a href="logout.php">Log Out</a></li>
        <?php else: ?>
        <li><a href="login.php">Log In</a></li>
        <?php endif; ?>
        <li><a class="active"  href="menu.php">Menu</a></li>
        <li><a href="landing.php">Home</a></li>
    </ul>

    <section class="reservation">
        <button class="reserve">Order Now</button>
    </section>



        <section class="cards">
            <div class="card1">
                <img class="image1" src="https://th.bing.com/th/id/R.c6227c5806ff4b134068ecac0b0dca93?rik=heN6kgks0A76bQ&riu=http%3a%2f%2fclpteensburgh.files.wordpress.com%2f2011%2f07%2fsalad.jpg&ehk=xqEy3dfnyvg5mkHe%2fcp6D43Yf6dt9CWonq1kkBzX9mc%3d&risl=&pid=ImgRaw&r=0">
                <p class="card1text">SALADS</p>
                <p class="cardsubtext1">Refreshing, delicious and just enough. Dive in into our variety of salads! They <br>are to  die for!</p>
                <button onclick="" class="view1">View more</button>
            </div>
            
            <div class="card2">
                <img class="image2" src="https://th.bing.com/th/id/R.ac3022bdeb3b71f0d128d5b242dc2f14?rik=IOneFEp9UJdCCA&pid=ImgRaw&r=0">
                <p class="card2text">MEAT DISHES</p>
                <p class="cardsubtext2">Enjoy great flavours of<br>meat, with a variety of meat<br>cuts.</p>
                <button onclick="" class="view2">View more</button>
            </div>

            <div class="card3">
                <img class="image3" src=https://th.bing.com/th/id/R.4ec8d7e51e98423abc6d2a92556deac9?rik=KHFipsG2FITq%2bw&riu=http%3a%2f%2fwww.relatemag.com%2fwp-content%2fuploads%2f2011%2f07%2fpasta-1024x682.jpg&ehk=%2buGpk8sZQwFXwWQgX2AAWU%2bXv%2by1eB3kc%2f2L3oPBk2U%3d&risl=&pid=ImgRaw&r=0>
                <p class="card3text">PASTA</p>
                <p class="cardsubtext3">Handmade pasta from our experienced <br> italian chefs.</p>
                <button onclick="" class="view3">View more</button>
            </div>

        </section>


        
        <section class="cards1">
            <div class="card1">
                <img class="image1" src="https://4.bp.blogspot.com/-N3LC8LhH8cQ/WRyLhxlEimI/AAAAAAAAIF8/utjOi77SWKgSPugRXs9Smbuzwlb2pzUYACEw/s1600/00000000000000000000A%2B%25281%2529.jpg">
                <p class="card1text">FISH</p>
                <p class="cardsubtext1">Have a great taste of sea food dishes <br> with a variety of types. </p>
                <button onclick="" class="view1">View more</button>
            </div>
            
            <div class="card2">
                <img class="image2" src="https://th.bing.com/th/id/R.3cc034f99f9d5964d65bd26e3e5c622b?rik=ZEWMv%2b1G9RG1Tg&riu=http%3a%2f%2fen.aleppofood.com%2frecipe-images%2fVegetables-Soup.jpeg&ehk=QebPikzw2zJtzVFisLb4cQQtaYsXpqji2qQ7sFzWfoM%3d&risl=&pid=ImgRaw&r=0">
                <p class="card2text">SOUPS</p>
                <p class="cardsubtext2">A delicacy of flavors, paried with <br> great creaminess.</p>
                <button onclick="" class="view2">View more</button>
            </div>

            <div class="card3">
                <img class="image3" src="https://th.bing.com/th/id/R.49af597ca10fceb7a1dfc8bcc6bc1026?rik=obkHWA26wpjaDw&riu=http%3a%2f%2fwww.fastfoodmenunutrition.com%2fwp-content%2fuploads%2f2015%2f03%2ffast-food.jpg&ehk=evPCWS01vOQotS5umzT4m4yZtp5yCtOnA6L8zfUa0L4%3d&risl=&pid=ImgRaw&r=0">
                <p class="card3text">FAST FOOD</p>
                <p class="cardsubtext3">From Cheeseburgers to <br>Chicken Nuggets, a huge variety of items tailored for you.</p>
                <button onclick="" class="view3">View more</button>
            </div>

        </section>



        

    </body>


</html>