
<!DOCTYPE html>
<html>
    <head>
        <title>Aura | Restaurant</title>
        <link rel="stylesheet" href="landingstyle.css">
    </head>
    <body>
        <section class="maintext">
             <section class="texts">
            <h1 class="herotext">Welcome to Aura Restaurant</h1>
            <h2 class="subtext">A variety of foods and a whole new experience</h2>
        </section>
    
        </section>

        <section class="logo">
            <img src="http://localhost/website/Logo.png">
        </section>

        <?php
    session_start();
    ?>

  
<ul class="navigation">
        <?php
        // Check if user is logged in
        if(isset($_SESSION['username'])):
        ?>
        <li><a href="#about"><?php echo $_SESSION['username']; ?></a></li>
        <li><a href="logout.php">Log Out</a></li>
        <?php else: ?>
        <li><a href="login.php">Login</a></li>
        <?php endif; ?>
        <li><a href="menu.php">Menu</a></li>
        <li><a class="active" href="landing.php">Home</a></li>
    </ul>


    <section class="reservation">
        <button class="reserve">Book a table</button>
    </section>



        <footer>
            <section class="aboutus">
                <p class="info">Established in 2015, Aura Restauarant is still<br>the greatest when it comes<br>at fine dining and elevated cuisine.</p>
                <p class="location">South Wood Cherry Oak Steet 219</p>
                <div class="contacts">
                    <button class="phone"><span class="btntitle1">Our Phone</span></button>
                    <button class="email"><span class="btntitle2">Our Email</span></button>
                    <button class="tiktok"><span class="btntitle3">Our TikTok</span>
                    </button>
                </div>
            </section>
        </footer>

        <section class="cards">
            <div class="card1">
                <img class="image1" src="https://i.pinimg.com/originals/23/13/f4/2313f4c93276746f56c2630094bccbd7.jpg">
                <p class="card1text">Great ambiance</p>
                <p class="cardsubtext1">A pleasure to eat and dine<br>with your family<br>and friends.</p>
                <button onclick="" class="view1">View more</button>
            </div>
            
            <div class="card2">
                <img class="image2" src="https://static.wixstatic.com/media/04ebdd_0253f1d3eaab470199ae7501376a0586.jpg/v1/fill/w_644,h_429,al_c,q_80,enc_auto/04ebdd_0253f1d3eaab470199ae7501376a0586.jpg">
                <p class="card2text">Mesmerizing structure</p>
                <p class="cardsubtext2">Empowering a modern & <br> fresh look paired with great <br>art.</p>
                <button onclick="" class="view2">View more</button>
            </div>

            <div class="card3">
                <img class="image3" src="https://kawarthanow.com/wp-content/uploads/2019/05/businessnow-may13-2019-fusion-bowl.jpg">
                <p class="card3text">Delicious food</p>
                <p class="cardsubtext3">Elevated flavours and cuisine, <br>delightful experiences.</p>
                <button onclick="" class="view3">View more</button>
            </div>


        </section>



    </body>


</html>